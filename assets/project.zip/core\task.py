from taskiq import InMemoryBroker


task_broker = InMemoryBroker()
